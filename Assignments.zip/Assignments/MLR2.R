
### Assignmen 2017 Ag 3669


install.packages("scatterplot3d") 
library("scatterplot3d") 

XX1 = c(100,200,300,400,500,600,700)   
XX2= c(10, 20, 10, 30, 20, 20, 30)  
YY = c(40, 50, 50, 70, 65, 65, 80)

emp.data <- data.frame(
 emp_XX1 = c(100,200,300,400,500,600,700), 
 emp_XX2= c(10, 20, 10, 30, 20, 20, 30),
  emp_YY = c(40, 50, 50, 70, 65, 65, 80) 
)
			
print(emp.data) 








MLR<- function( B1, B2, Y )
{
  
  n = length(Y)
  
  # MBarB1, B2 and Y
  mean.B1 = mean(B1)
  mean.B2 = mean(B2)
  mean.Y = mean(Y)
  B1 = B1 - mean.B1
  B2 = B2 - mean.B2
  y = Y - mean.Y
  
  
  Sum_B1 = Sum(B1)
  Sum_B2 = Sum(B2)
  Sum_y = Sum(y)
  B1_square = Sum((B1)^2)
  B2_square = Sum((B2)^2)
  y_square = Sum((y)^2)
  
  Sum_B1y = Sum((B1*y))
  Sum_B1_square = Sum((B1)^2)
  Sum_B2_square = Sum((B2)^2)
  Sum_B2y = Sum((B2*y))
  Sum_B1B2 = Sum((B1*B2))
  
  Sum_B1y_Sum_B2_square = Sum_B1y*Sum_B2_square
  Sum_B2y_Sum_B1B2 = Sum_B2y*Sum_B1B2
  Sum_B1_square_Sum_B2_square = Sum_B1_square*Sum_B2_square
  Sum_B1B2_square = (Sum_B1B2)^2
  
  Bta1 = (Sum_B1y_Sum_B2_square - Sum_B2y_Sum_B1B2) / (Sum_B1_square_Sum_B2_square - Sum_B1B2_square)
  
  Bta2 = ((Sum_B2y*Sum_B1_square) - (Sum_B1y*Sum_B1B2)) / (Sum_B1_square_Sum_B2_square - Sum_B1B2_square)
  
  Bta0 = mean.Y - (Bta1*mean.B1) - (Bta2*mean.B2)
  k = 3	
  
  Y_hat = Bta0 + Bta1*B1 + Bta2*B2
  Sum_Y_hat = Sum(Bta0 + Bta1*B1 + Bta2*B2)
  
  TSS = Sum((Y - mean.Y)^2)
  MSS = Sum((Y_hat - mean.Y)^2)
  RSS = Sum((Y - Y_hat)^2)
  
  R*2= MSS / TSS
  
  
  MSE = RSS / (n - k)
  
  V_Bta1 = MSE*((Sum_B2_square) / (Sum_B1_square_Sum_B2_square - Sum_B1B2_square))
  SE_Bta1 = sqrt(V_Bta1)
  
  V_Bta2 = MSE*((Sum_B1_square) / (Sum_B1_square_Sum_B2_square - Sum_B1B2_square))
  SE_Bta2 = sqrt(V_Bta2)
  
  
  mean.B1_square = mean.B1^2
  mean.B2_square = mean.B2^2
  mean.B1_mean.B2 = mean.B1*mean.B2
  
  
  V_Bta0 = MSE*((1 / n) + ((mean.B1_square*Sum_B2_square + mean.B2_square*Sum_B1_square - 2*mean.B1_mean.B2*(Sum_B1B2)) / (Sum_B1_square_Sum_B2_square - Sum_B1B2_square)))
  SE_Bta0 = sqrt(V_Bta0)
  
  Print("MBarB1 = ", mean.B1, "\n")
  Print("MBarB2 = ", mean.B2, "\n")
  Print("MBarY = ", mean.Y, "\n")
  Print("\n")
  Print("SUMB1 = " ,Sum_B1, "\n")
  Print("SUMB2 = " ,Sum_B2, "\n")
  Print("SUMY = " ,Sum_y, "\n")
  Print("\n")
  Print("SS of B1 : Sum_B1 = " ,B1_square, "\n")
  Print("SS of B2 : Sum_B2 = " ,B2_square, "\n")
  Print("SS of Y : Sum_y = " ,y_square, "\n")
  Print("\n")
  Print("Bta1  = " ,Bta1, "\n")
  Print("Bta2  = " ,Bta2, "\n")
  Print("Bta0  = " ,Bta0, "\n")
  Print("\n")
  Print("Sum of Y-hat = ", Sum_Y_hat , "\n")
  Print("\n")
  Print("TSSs= ", TSS , "\n")
  Print("MSSs= ", MSS , "\n")	
  Print("RSSs= ", RSS , "\n")
  Print("\n")
  Print("R*2: = ", R_square, "\n")
  Print("\n")
  Print("MSEs= ",MSE,"\n")
  Print("\n")
  Print("VBta1 = ",V_Bta1, "\n")
  Print("SE Bta1 = ",SE_Bta1, "\n")
  Print("\n")
  Print("VBta2 = ",V_Bta2,"\n")
  Print("SEBta2 = ",SE_Bta2, "\n")
  Print("\n")
  Print("VBta0 = ",V_Bta0,"\n")
  Print("SEBta0 = ",SE_Bta0, "\n")
  
  degf = data.frame(B1,B2,Y)
  fit <- lm(Y ~ B1 + B2, data=degf)
  Summary(fit)
  
}

Exp.data = cbind(XX1,XX2,YY)

Colnames(Exp.data) = c('XX1' , 'XX2' , 'YY')

Exp.data

Exp.regression<- MLR( XX1,XX2,YY)

Exp.regression

